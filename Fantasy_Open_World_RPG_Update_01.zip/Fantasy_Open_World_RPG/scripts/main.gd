extends Control

const SAVE_PATH := "user://savegame.json"

var hero := {
    "name": "Adventurer",
    "class": "Wanderer",
    "attribute_points": 0,
    "level": 1,
    "exp": 0,
    "next_exp": 100,
    "hp": 100,
    "max_hp": 100,
    "mp": 30,
    "max_mp": 30,
    "attack": 12,
    "defense": 5,
    "gold": 25,
    "potions": 3
}
var location := "Whispering Village"
var log_lines: Array[String] = ["Welcome, adventurer. Your journey begins in Whispering Village."]
var enemy: Dictionary = {}
var in_battle := false

var status_label: Label
var location_label: Label
var log_label: RichTextLabel
var actions: VBoxContainer
var title_label: Label

func _ready() -> void:
    build_ui()
    refresh()

func build_ui() -> void:
    var bg := ColorRect.new()
    bg.color = Color("#101522")
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 22)
    margin.add_theme_constant_override("margin_right", 22)
    margin.add_theme_constant_override("margin_top", 24)
    margin.add_theme_constant_override("margin_bottom", 24)
    add_child(margin)

    var column := VBoxContainer.new()
    column.add_theme_constant_override("separation", 12)
    margin.add_child(column)

    title_label = Label.new()
    title_label.text = "FANTASY REALMS"
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.add_theme_font_size_override("font_size", 30)
    title_label.add_theme_color_override("font_color", Color("#e9c77b"))
    column.add_child(title_label)

    status_label = Label.new()
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    column.add_child(status_label)

    location_label = Label.new()
    location_label.add_theme_font_size_override("font_size", 18)
    location_label.add_theme_color_override("font_color", Color("#9ed6c2"))
    column.add_child(location_label)

    var separator := HSeparator.new()
    column.add_child(separator)

    log_label = RichTextLabel.new()
    log_label.bbcode_enabled = true
    log_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
    log_label.scroll_following = true
    log_label.add_theme_font_size_override("normal_font_size", 16)
    column.add_child(log_label)

    var sep2 := HSeparator.new()
    column.add_child(sep2)

    actions = VBoxContainer.new()
    actions.add_theme_constant_override("separation", 8)
    column.add_child(actions)
    show_exploration_actions()

func add_action(text: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = text
    button.custom_minimum_size = Vector2(0, 54)
    button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    button.add_theme_font_size_override("font_size", 17)
    button.pressed.connect(callback)
    actions.add_child(button)

func clear_actions() -> void:
    for child in actions.get_children():
        child.queue_free()

func show_exploration_actions() -> void:
    clear_actions()
    add_action("Explore the nearby forest", explore_forest)
    add_action("Rest at the village inn", rest)
    add_action("Character status", show_status)
    add_action("Choose character class", show_class_menu)
    add_action("Allocate attribute points", show_attribute_menu)
    add_action("Inventory", show_inventory)
    add_action("Save game", save_game)
    add_action("Load game", load_game)

func show_battle_actions() -> void:
    clear_actions()
    add_action("Attack", player_attack)
    add_action("Class skill (uses MP)", use_class_skill)
    add_action("Heavy strike (uses 8 MP)", heavy_strike)
    add_action("Use potion", use_potion)
    add_action("Defend", defend_turn)
    add_action("Attempt to flee", flee)

func refresh() -> void:
    status_label.text = "%s  |  Lv.%d  |  EXP %d/%d\nHP %d/%d   MP %d/%d   ATK %d   DEF %d   Gold %d" % [
        hero.name, hero.level, hero.exp, hero.next_exp, hero.hp, hero.max_hp,
        hero.mp, hero.max_mp, hero.attack, hero.defense, hero.gold
    ]
    location_label.text = "Location: " + location
    log_label.clear()
    for line in log_lines:
        log_label.append_text(line + "\n")

func say(message: String) -> void:
    log_lines.append(message)
    if log_lines.size() > 80:
        log_lines.pop_front()
    refresh()

func explore_forest() -> void:
    location = "Whispering Forest"
    if randi_range(1, 100) <= 72:
        var encounter := randi_range(1, 4)
        match encounter:
            1:
                enemy = {"name": "Forest Wolf", "level": 1, "hp": 34, "max_hp": 34, "attack": 9, "defense": 2, "exp": 35, "gold": 8}
            2:
                enemy = {"name": "Moss Slime", "level": 1, "hp": 27, "max_hp": 27, "attack": 7, "defense": 1, "exp": 25, "gold": 5}
            3:
                enemy = {"name": "Thorn Boar", "level": 2, "hp": 46, "max_hp": 46, "attack": 12, "defense": 3, "exp": 48, "gold": 12}
            _:
                enemy = {"name": "Forest Bandit", "level": 2, "hp": 40, "max_hp": 40, "attack": 13, "defense": 2, "exp": 52, "gold": 16}
        in_battle = true
        say("[color=#e7a0a0]%s appears! (Lv.%d, HP %d)[/color]" % [enemy.name, enemy.level, enemy.hp])
        show_battle_actions()
    else:
        var found := randi_range(5, 18)
        hero.gold += found
        say("You explore the forest and find %d gold among the roots." % found)
        show_exploration_actions()
    refresh()

func player_attack() -> void:
    var damage: int = max(1, hero.attack + randi_range(-3, 4) - int(enemy.defense))
    enemy.hp -= damage
    say("You attack %s for %d damage." % [enemy.name, damage])
    resolve_enemy_state()

func heavy_strike() -> void:
    if hero.mp < 8:
        say("Not enough MP.")
        return
    hero.mp -= 8
    var damage: int = max(2, hero.attack * 2 + randi_range(0, 5) - int(enemy.defense))
    enemy.hp -= damage
    say("Heavy Strike deals %d damage!" % damage)
    resolve_enemy_state()

func resolve_enemy_state() -> void:
    if enemy.hp <= 0:
        say("[color=#e9c77b]%s is defeated! You gain %d EXP and %d gold.[/color]" % [enemy.name, enemy.exp, enemy.gold])
        hero.exp += enemy.exp
        hero.gold += enemy.gold
        in_battle = false
        check_level_up()
        location = "Whispering Forest"
        show_exploration_actions()
        refresh()
        return
    enemy_turn()

func enemy_turn() -> void:
    var damage: int = max(1, int(enemy.attack) + randi_range(-2, 3) - hero.defense)
    hero.hp = max(0, hero.hp - damage)
    say("%s attacks you for %d damage. Enemy HP: %d/%d." % [enemy.name, damage, enemy.hp, enemy.max_hp])
    if hero.hp <= 0:
        say("[color=#e7a0a0]You have been defeated. You wake up at the village with half your gold lost.[/color]")
        hero.gold = int(hero.gold / 2)
        hero.hp = max(1, int(hero.max_hp / 2))
        hero.mp = max(0, int(hero.max_mp / 2))
        in_battle = false
        location = "Whispering Village"
        show_exploration_actions()
    refresh()

func use_potion() -> void:
    if hero.potions <= 0:
        say("You have no potions.")
        return
    if hero.hp == hero.max_hp:
        say("Your HP is already full.")
        return
    hero.potions -= 1
    var healed: int = min(45, hero.max_hp - hero.hp)
    hero.hp += healed
    say("You drink a potion and recover %d HP." % healed)
    enemy_turn()

func defend_turn() -> void:
    var damage: int = max(1, int(enemy.attack / 2) - hero.defense)
    hero.hp = max(0, hero.hp - damage)
    say("You brace for impact and take only %d damage." % damage)
    if hero.hp <= 0:
        enemy_turn()
    refresh()

func flee() -> void:
    if randi_range(1, 100) <= 55:
        say("You escape from battle.")
        in_battle = false
        location = "Whispering Forest"
        show_exploration_actions()
    else:
        say("You fail to escape!")
        enemy_turn()
    refresh()

func check_level_up() -> void:
    while hero.exp >= hero.next_exp:
        hero.exp -= hero.next_exp
        hero.level += 1
        hero.next_exp = int(round(hero.next_exp * 1.35))
        hero.max_hp += 15
        hero.max_mp += 5
        hero.attack += 3
        hero.defense += 1
        hero.attribute_points += 3
        hero.hp = hero.max_hp
        hero.mp = hero.max_mp
        say("[color=#e9c77b]LEVEL UP! You reached level %d. Your attributes increased.[/color]" % hero.level)


func show_class_menu() -> void:
    if hero["class"] != "Wanderer":
        say("Your class is already set to %s. Class changes are locked for this character." % hero["class"])
        return
    clear_actions()
    say("Choose your calling. This decision is permanent.")
    add_action("Warrior — durable melee fighter", func(): choose_class("Warrior"))
    add_action("Mage — powerful magic user", func(): choose_class("Mage"))
    add_action("Ranger — precise and versatile hunter", func(): choose_class("Ranger"))
    add_action("Back", show_exploration_actions)

func choose_class(chosen_class: String) -> void:
    hero["class"] = chosen_class
    match chosen_class:
        "Warrior":
            hero.max_hp += 35
            hero.hp = hero.max_hp
            hero.attack += 3
            hero.defense += 3
        "Mage":
            hero.max_mp += 35
            hero.mp = hero.max_mp
            hero.attack += 5
            hero.defense += 1
        "Ranger":
            hero.max_hp += 10
            hero.hp = hero.max_hp
            hero.attack += 4
            hero.defense += 2
    say("You have become a %s. Your class skill is now available in battle." % chosen_class)
    show_exploration_actions()
    refresh()

func show_attribute_menu() -> void:
    clear_actions()
    say("Unspent attribute points: %d. Each point improves one attribute." % int(hero.attribute_points))
    if int(hero.attribute_points) <= 0:
        add_action("Back", show_exploration_actions)
        return
    add_action("Vitality (+10 maximum HP)", func(): spend_attribute("vitality"))
    add_action("Strength (+2 attack)", func(): spend_attribute("strength"))
    add_action("Fortitude (+1 defense)", func(): spend_attribute("fortitude"))
    add_action("Mind (+5 maximum MP)", func(): spend_attribute("mind"))
    add_action("Back", show_exploration_actions)

func spend_attribute(attribute: String) -> void:
    if int(hero.attribute_points) <= 0:
        show_exploration_actions()
        return
    hero.attribute_points -= 1
    match attribute:
        "vitality":
            hero.max_hp += 10
            hero.hp += 10
        "strength":
            hero.attack += 2
        "fortitude":
            hero.defense += 1
        "mind":
            hero.max_mp += 5
            hero.mp += 5
    say("Attribute increased: %s. Points remaining: %d." % [attribute.capitalize(), hero.attribute_points])
    show_attribute_menu()
    refresh()

func use_class_skill() -> void:
    var cost := 10
    if hero["class"] == "Mage":
        cost = 12
    if hero.mp < cost:
        say("Not enough MP to use your class skill.")
        return
    hero.mp -= cost
    var damage := 0
    match hero["class"]:
        "Warrior":
            damage = max(1, hero.attack * 2 + randi_range(2, 7) - int(enemy.defense))
            say("Power Slash strikes for %d damage!" % damage)
        "Mage":
            damage = max(1, hero.attack * 2 + randi_range(8, 14) - int(enemy.defense))
            say("Arcane Bolt hits for %d magic damage!" % damage)
        "Ranger":
            damage = max(1, int(hero.attack * 1.6) + randi_range(5, 10) - int(enemy.defense))
            say("Piercing Shot deals %d damage!" % damage)
        _:
            say("Choose a class before using a class skill.")
            hero.mp += cost
            return
    enemy.hp -= damage
    resolve_enemy_state()

func rest() -> void:
    hero.hp = hero.max_hp
    hero.mp = hero.max_mp
    say("You rest at the inn. HP and MP are fully restored.")
    refresh()

func show_status() -> void:
    say("STATUS — %s | Level %d | EXP %d/%d | HP %d/%d | MP %d/%d | ATK %d | DEF %d | Attribute points %d" % [
        hero["class"], hero.level, hero.exp, hero.next_exp, hero.hp, hero.max_hp, hero.mp, hero.max_mp,
        hero.attack, hero.defense, hero.attribute_points
    ])

func show_inventory() -> void:
    say("INVENTORY — Potions: %d | Gold: %d" % [hero.potions, hero.gold])

func save_game() -> void:
    var data := {"hero": hero, "location": location, "log_lines": log_lines}
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(data))
        say("Game saved successfully.")
    else:
        say("Could not save the game.")

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        say("No save file found yet.")
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        hero = parsed.get("hero", hero)
        location = parsed.get("location", "Whispering Village")
        log_lines = parsed.get("log_lines", [])
        in_battle = false
        say("Saved game loaded.")
        show_exploration_actions()
        refresh()
    else:
        say("Save file could not be read.")
