FANTASY OPEN WORLD RPG — GODOT STARTER PROJECT

This is a starter Godot 4 project for a text-based, turn-based fantasy RPG.

Included:
- Mobile-friendly text UI
- Character status, HP, MP, attack, defense, gold
- Forest exploration and random Forest Wolf encounters
- Turn-based combat: attack, heavy strike, potion, defend, flee
- EXP and level-ups
- Rest, inventory display, save/load

How to open:
1. Install Godot Engine 4.x on a computer.
2. Extract this ZIP.
3. In Godot, choose Import and select project.godot.
4. Press F6/F5 to run the project.

How to export to Android:
1. Install Android export templates in Godot.
2. Configure Android SDK/JDK in Editor Settings.
3. Add an Android export preset and set package name.
4. Export APK.

Note:
This ZIP contains the editable Godot project source, not a compiled APK.
Godot and Android build tools are not available in this workspace, so the APK
cannot be compiled here. The project must be exported with Godot on a computer.


UPDATE 1 — CLASS & ATTRIBUTE SYSTEM
- Added permanent class choice: Warrior, Mage, Ranger.
- Added class-specific battle skills with MP costs.
- Level-ups now grant 3 attribute points.
- Added point allocation: Vitality, Strength, Fortitude, Mind.
- Forest encounters now include Forest Wolf, Moss Slime, Thorn Boar, and Forest Bandit.
- Class and attribute progress are included in the existing save data.
